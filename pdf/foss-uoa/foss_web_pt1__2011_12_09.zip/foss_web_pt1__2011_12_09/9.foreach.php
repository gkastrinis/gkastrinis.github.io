<?php
	$fruits = array(
		"banana" => "yellow",
		"apple" => "red",
		"coconut" => "brown"
	);

	foreach ($fruits as $f => $c)
		echo "Fruit $f : $c";
?>
