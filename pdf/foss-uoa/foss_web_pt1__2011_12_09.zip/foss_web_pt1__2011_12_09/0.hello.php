<?php
	echo 'Hello DI';
?>
