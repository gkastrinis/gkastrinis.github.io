<?php
	$foo = 'single quotes';
	$foo = "double quotes";
	$bar = 'one ' . 'two ';
	$bar .= 'three';
?>
