<?php
	$simple = array(1, 13, 7);
	$assosiative = array(
		"foo" => 2,
		"bar" => 39,
		9 => 42);
	$assosiative['lala'] = 0;
	echo $simple[2];
	echo $assosiative['bar'];
?>
