<?php

error_reporting(E_ALL ^ E_NOTICE);

/*=========== Database Configuration ==========*/

$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'password';
$db_name = 'forum';

?>
