<?php

class Post
{

}

?>
