<?php

class Thread
{

}

?>
